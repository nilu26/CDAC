﻿using LabExam.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LabExam.Controllers
{
    public class ProductController : Controller
    {
        public ActionResult PartialV()
        {
            return View();
        }
        // GET: Product
        public ActionResult Index()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=(localdb)\MSSQLLOCALDB;Initial Catalog=ExamDB; Integrated Security = True;";
            List<Product> productlist = new List<Product>();
            try
            {
                con.Open();
                SqlCommand cmdCreate = new SqlCommand();
                cmdCreate.Connection = con;
                cmdCreate.CommandType = System.Data.CommandType.StoredProcedure;
                cmdCreate.CommandText = "ListProduct";
                SqlDataReader dr = cmdCreate.ExecuteReader();

                while (dr.Read())
                {
                    productlist.Add(new Product { ProductId = (int)dr["ProductId"], ProductName = dr["ProductName"].ToString(), Rate=(decimal)dr["Rate"] , Description = dr["Description"].ToString(), CategoryName = dr["CategoryName"].ToString() });
                }
                
                return View(productlist);
            }
            catch (Exception e)
            {
                ViewBag.Message = e.Message;
                return View();
            }
            finally
            {
                con.Close();
            }
        }

        // GET: Product/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Product/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Product/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Product/Edit/5
        public ActionResult Edit(int id)
        {
            Product plist = new Product();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=(localdb)\MSSQLLOCALDB;Initial Catalog=ExamDB; Integrated Security = True;";
            try
            {
                con.Open();
                SqlCommand cmdCreate = new SqlCommand();
                cmdCreate.Connection = con;
                cmdCreate.CommandType = System.Data.CommandType.StoredProcedure;
                cmdCreate.CommandText = "getProducts";
                cmdCreate.Parameters.AddWithValue("@ProductId", id);
                SqlDataReader dr = cmdCreate.ExecuteReader();
                while (dr.Read())
                {
                    plist = new Product { ProductId = (int)dr["ProductId"], ProductName = dr["ProductName"].ToString(), Rate = (decimal)dr["Rate"], Description = dr["Description"].ToString(), CategoryName = dr["CategoryName"].ToString() };
                }
                dr.Close();

            }
            catch (Exception e)
            {
                ViewBag.Message = e.Message;
            }
            finally
            {
                con.Close();
            }
            return View(plist);
        }

        // POST: Product/Edit/5
        [HttpPost]
        public ActionResult Edit(Product obj)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=(localdb)\MSSQLLOCALDB;Initial Catalog=ExamDB; Integrated Security = True;";
            try
            {
                con.Open();
                SqlCommand cmdCreate = new SqlCommand();
                cmdCreate.Connection = con;
                cmdCreate.CommandType = System.Data.CommandType.StoredProcedure;
                cmdCreate.CommandText = "EditProduct";
                cmdCreate.Parameters.AddWithValue("@PId", obj.ProductId);
                cmdCreate.Parameters.AddWithValue("@PName", obj.ProductName);
                cmdCreate.Parameters.AddWithValue("@PRate", obj.Rate);
                cmdCreate.Parameters.AddWithValue("@PDescription", obj.Description);
                cmdCreate.Parameters.AddWithValue("@PCategoryName", obj.CategoryName);
                cmdCreate.ExecuteNonQuery();
                return RedirectToAction("Index");

            }
            catch (Exception e)
            {
                ViewBag.Message = e.Message;
                return View();
            }
            finally
            {
                con.Close();
            }
        }

        // GET: Product/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Product/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
