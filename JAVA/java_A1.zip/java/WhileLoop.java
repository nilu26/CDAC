class WhileLoop
{
	public static void main(String args[])
	{
		System.out.println("While Loop");
		int i = 10;
		while(i >= 1)
		{
			System.out.println(i);
			i--;
		}
	}
}