class Circle
{
	public static void main(String args[])
	{
		int r;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter radius: ");
		r=sc.nextInt();
		
	}
}