import java.util.*;
class Add{

public static void main(String[] args){

int a, b;
System.out.println("Enter First Number: ");
Scanner sc=new Scanner(System.in);
a=sc.nextInt();
System.out.println("Enter Second Number: ");
b=sc.nextInt();

System.out.println("Addition of two Number is: "+(a+b));
}
}