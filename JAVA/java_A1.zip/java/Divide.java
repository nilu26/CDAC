import java.util.*;
class Divide{
	public static void main(String[] args){
		int a,b;
		System.out.println("Enter First Number: ");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		
		System.out.println("Enter Second Number: ");
		b=sc.nextInt();
		
		System.out.println("Divide: "+(a/b));
	}

}